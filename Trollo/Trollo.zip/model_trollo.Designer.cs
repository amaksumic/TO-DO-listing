﻿// Default code generation is disabled for model 'C:\Users\Haana\Documents\GitHub\TO-DO-listing\Trollo\Trollo\model_trollo.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.